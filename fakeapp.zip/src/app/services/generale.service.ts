import { HttpClientModule,HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Impiegato } from '../models/impiegato';


@Injectable({
  providedIn: 'root'
})
export class GeneraleService {

urlImpiegati = "http://localhost:4201/Impiegati";

  constructor(private http:HttpClient) { }

  registrazione(dati:Impiegato){
    return this.http.post(`${this.urlImpiegati}/register`, dati);
  }


}
