export interface Clienti {
  name:string,
  address:string,
  city:string,
  province:string,
  id:number,
  idImpiegato:number
}
