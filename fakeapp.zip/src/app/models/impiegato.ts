
export interface Impiegato {
  email:string,
  password:string,
  name:string,
  address:string,
  city:string,
  province:string,
  id:number,
  type?:'Amministrativo'|'Contabile'|'Commerciale',
  token: string
}
