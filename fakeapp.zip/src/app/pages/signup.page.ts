import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Impiegato } from '../models/impiegato';
import { GeneraleService } from '../services/generale.service';

@Component({
  template: `
    <div class="row justify-content-center">
      <div class="col-6">
        <form #form="ngForm" (ngSubmit)="onsubmit(form)">
          <div class="form-group">
            <label for="name">Nome completo</label>
            <input
              ngModel
              name="name"
              class="form-control"
              type="text"
              id="name"
            />
          </div>
          <div class="form-group">
            <label for="address">Indirizzo</label>
            <input
              ngModel
              name="address"
              class="form-control"
              type="text"
              id="address"
            />
          </div>
          <div class="form-group">
            <label for="city">Città</label>
            <input
              ngModel
              name="city"
              class="form-control"
              type="text"
              id="city"
            />
          </div>
          <div class="form-group">
            <label for="province">Provincia</label>
            <input
              ngModel
              name="province"
              class="form-control"
              type="text"
              id="province"
            />
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input
              ngModel
              name="email"
              class="form-control"
              type="email"
              id="email"
            />
          </div>
          <div class="form-group">
            <label for="pass">Password</label>
            <input
              ngModel
              name="password"
              class="form-control"
              type="password"
              id="pass"
            />
          </div>
          <div class="form-group">
            <label for="seleziona">Seleziona il tuo status di impiegato:</label>
            <select
              class="form-select"
              aria-label="Default select example"
              id="seleziona"
            >
              <option selected></option>
              <option value="Amministrativo">Amministrativo</option>
              <option value="Contabile">Contabile</option>
              <option value="Commerciale">Commerciale</option>
            </select>
          </div>
          <button class="btn btn-primary mt-3" type="submit">Registrati</button>
        </form>
      </div>
    </div>
  `,
  styles: [],
})
export class SignupPage implements OnInit {
  constructor(
    private gen: GeneraleService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {}

  onsubmit(form: NgForm) {
    console.log(form.value);

      this.gen.registrazione(form.value).subscribe((res) => {
        console.log(res);
        this.router.navigate(['/login']);
      });
  }
}
