import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <p>
      login works!
    </p>
  `,
  styles: [
  ]
})
export class LoginPage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
